using System;
using System.Collections.Generic;
using System.Reflection;
using BepInEx;
using BepInEx.Configuration;
using HarmonyLib;
using UnityEngine;

// Instrument Display - a minimal, customizable vessel telemetry overlay for Sailwind.
// A derivative of BoatStatusHUD by luizbag (https://github.com/luizbag/BoatStatusHUD),
// reorganized and extended to work across stock and modded ships. Maintained by Dixiecapt.
namespace MarinersHUD
{
    [BepInPlugin(PluginInfo.GUID, PluginInfo.Name, PluginInfo.Version)]
    public class MarinersHUDPlugin : BaseUnityPlugin
    {
        public static class PluginInfo
        {
            public const string GUID = "com.dixiecapt.sailwind.marinershud";
            public const string Name = "MarinersHUD";
            public const string Version = "1.0.1";
        }

        public static BoatDamage CurrentBoatDamage;

        private static readonly FieldInfo SelfMassField = AccessTools.Field(typeof(BoatMass), "selfMass");
        private static readonly FieldInfo PartsMassField = AccessTools.Field(typeof(BoatMass), "partsMass");
        private static readonly FieldInfo ItemsOnBoatField = AccessTools.Field(typeof(BoatMass), "itemsOnBoat");
        private static readonly FieldInfo CloudyBorderField = AccessTools.Field(typeof(WeatherStorms), "cloudyBorder");
        private static readonly FieldInfo RainBorderField = AccessTools.Field(typeof(WeatherStorms), "rainBorder");

        private const float PlayerMassLbs = 160f; // the game adds exactly this for the player in BoatMass.UpdateMass

        private static readonly string[] CompassPoints = new string[] {
            "N","NNE","NE","ENE","E","ESE","SE","SSE","S","SSW","SW","WSW","W","WNW","NW","NNW" };

        // --- Config: weight profiles ---
        private ConfigEntry<string> _shipProfilesConfig;
        private ConfigEntry<float> _defaultMaxWeightLbsConfig;
        private ConfigEntry<float> _lightThresholdPctConfig;
        private ConfigEntry<float> _loadedThresholdPctConfig;
        private ConfigEntry<float> _overloadedThresholdPctConfig;
        private ConfigEntry<bool> _debugReadoutConfig;

        // --- Config: HUD sections ---
        private ConfigEntry<bool> _hudVisibleConfig;
        private ConfigEntry<bool> _showInstrumentsConfig;
        private ConfigEntry<bool> _showCargoConfig;
        private ConfigEntry<bool> _showSoundingConfig;
        private ConfigEntry<bool> _showStatusConfig;
        private ConfigEntry<bool> _showWeatherConfig;
        private ConfigEntry<KeyCode> _hudToggleKeyConfig;
        private ConfigEntry<KeyCode> _instrumentsToggleKeyConfig;
        private ConfigEntry<KeyCode> _cargoToggleKeyConfig;
        private ConfigEntry<KeyCode> _soundingToggleKeyConfig;
        private ConfigEntry<KeyCode> _statusToggleKeyConfig;
        private ConfigEntry<KeyCode> _weatherToggleKeyConfig;

        // --- Config: appearance ---
        private ConfigEntry<string> _fontNameConfig;
        private ConfigEntry<int> _fontSizeConfig;
        private ConfigEntry<float> _panelAlphaConfig;
        private ConfigEntry<float> _textAlphaConfig;
        private ConfigEntry<bool> _textShadowConfig;

        // --- Config: equipment requirements ---
        private ConfigEntry<bool> _requireChipLogConfig;
        private ConfigEntry<bool> _requireCompassConfig;
        private ConfigEntry<bool> _requireWindIndicatorConfig;
        private ConfigEntry<string> _chipLogNamesConfig;
        private ConfigEntry<string> _compassNamesConfig;
        private ConfigEntry<string> _windIndicatorNamesConfig;

        private class ShipProfile
        {
            public string NameContains;
            public float MaxWeightLbs;
            public float EmptyWeightLbs;
            public bool HasEmptyWeight;
        }

        private readonly List<ShipProfile> _shipProfiles = new List<ShipProfile>();

        // ---- Telemetry snapshot (computed in Update, drawn in OnGUI) ----
        private bool _snapValid;
        private float _snapSpeedKts;
        private float _snapHeadingDeg;
        private float _snapHeel;
        private bool _snapHeelPort;
        private float _snapHeelLimit;
        private float _snapWindKts;
        private float _snapWindFromDeg;
        private float _snapHullDamagePct;
        private float _snapBilgePct;
        private bool _snapSunk;
        private float _snapDeadweightLbs;
        private float _snapBilgeEqLbs;
        private float _snapSelfMass;
        private float _snapPartsMass;
        private float _snapMaxSafeLbs;
        private float _snapBurdenLoadLbs;
        private bool _snapBurdenIsTotalBased;
        private bool _snapProfileMatched;
        private string _snapBoatName = "";
        private int _snapConditionSeverity; // 0 fair, 1 moderate, 2 squally, 3 tempest
        private float _stormProximity = 1f;    // smoothed 0=in storm .. 1=clear
        private bool _stormProximityInit;
        private float _conditionHoldTimer;
        // Sounding / freeboard (throttled)
        private float _keelTimer;
        private float _snapKeelClearance = 999f;
        private float _snapSeaDepth = 999f;
        private string _snapKeelHitName = "(no hit)";
        private float _snapFreeboard;
        private bool _freeboardInitialized;
        // Equipment scan (1 Hz)
        private float _equipScanTimer;
        private bool _hasChipLog;
        private bool _hasCompass;
        private bool _hasWindIndicator;
        // Font
        private Font _gameFont;
        private bool _fontSearched;

        private void Awake()
        {
            try
            {
                BindConfig();
                var harmony = new Harmony(PluginInfo.GUID);
                harmony.PatchAll();
                Logger.LogInfo("[" + PluginInfo.Name + "] Telemetry system successfully initialized.");
            }
            catch (System.Exception ex)
            {
                Logger.LogError("[" + PluginInfo.Name + "] Critical failure hook mapping: " + ex.Message);
            }
        }

        private void BindConfig()
        {
            _shipProfilesConfig = Config.Bind(
                "ShipWeightProfiles",
                "Profiles",
                "dhow small=400;dhow medium=800;dhow large=6000;" +
                "medi small=700;medi medium=10000;medi large=10000;" +
                "junk small=600;junk medium=4000;junk large=17000;" +
                "Gallus=400;Caelanor=2000;Gloriana=12000;Chronian=17000;Leopard=20000;" +
                "Shroud Small=600;Shroud Large=9000;BOAT CUTTER=250;DNG=150",
                "Format: NameMatch=MaxSafeWeightLbs  or  NameMatch=MaxSafeWeightLbs:EmptyWeightLbs, ';'-separated.\n" +
                "NameMatch is a case-insensitive substring of the boat's internal GameObject name.\n" +
                "MaxSafeWeightLbs is the safe carrying capacity used by the Burden rating.\n" +
                "EmptyWeightLbs (optional) is the ship's TOTAL weight when empty with stock fittings (read the\n" +
                "Debug 'Total Weight' line on an empty ship). When provided, Burden is computed from real total\n" +
                "weight, so heavy shipyard customizations correctly eat into remaining capacity.\n" +
                "IMPORTANT: entries are checked in order and the FIRST match wins, and matching is against\n" +
                "the boat's INTERNAL name, not the shipyard name. Stock hulls are internally named by\n" +
                "region+size: 'dhow small/medium/large', 'medi small/medium/large', 'junk small/medium/large'\n" +
                "(e.g. the Cog is 'BOAT medi small (40)', the Kakam is 'BOAT dhow small (10)').\n" +
                "The Aelasyl's internal name is 'BOAT CHRONIAN (187)' - use Chronian, not Aelasyl.\n" +
                "Capacities for junk small, medi medium/large, Shroud Small/Large, BOAT CUTTER and DNG are\n" +
                "estimates - verify with the Debug readout and tune to taste.");

            _defaultMaxWeightLbsConfig = Config.Bind("ShipWeightProfiles", "DefaultMaxWeightLbs", 5000f,
                "Capacity used when the boat matches no profile. Burden shows '(no profile)' when in use.");

            _lightThresholdPctConfig = Config.Bind("LoadStatusThresholds", "LightBelowPercent", 40f,
                "Below this % of capacity, Burden shows 'Light'.");
            _loadedThresholdPctConfig = Config.Bind("LoadStatusThresholds", "LoadedAbovePercent", 80f,
                "At or above this % (but under the overload point), Burden shows 'Loaded'.");
            _overloadedThresholdPctConfig = Config.Bind("LoadStatusThresholds", "OverloadedAtPercent", 100f,
                "At or above this % of capacity, Burden shows 'Overloaded'.");

            _debugReadoutConfig = Config.Bind("Debug", "DebugMassReadout", false,
                "Adds raw hull/parts/total mass, boat internal name, matched capacity, the sounding-ray hit, " +
                "and logs the game font names found (for the FontName setting).");

            _hudVisibleConfig = Config.Bind("HUDSections", "HudVisible", true, "Master switch for the whole HUD.");
            _showInstrumentsConfig = Config.Bind("HUDSections", "ShowInstruments", true,
                "Instruments section (Speed / Heading / Heel).");
            _showCargoConfig = Config.Bind("HUDSections", "ShowCargo", true,
                "Cargo section (Deadweight / Freeboard / Burden).");
            _showSoundingConfig = Config.Bind("HUDSections", "ShowSounding", true,
                "Sounding section (Sea Depth / Keel Clearance).");
            _showStatusConfig = Config.Bind("HUDSections", "ShowStatus", true,
                "Status section (Hull Integrity / Bilge Water).");
            _showWeatherConfig = Config.Bind("HUDSections", "ShowWeather", true,
                "Weather section (Wind / Conditions).");

            _hudToggleKeyConfig = Config.Bind("HUDSections", "HudToggleKey", KeyCode.F8,
                "Key that shows/hides the entire HUD. None to disable.");
            _instrumentsToggleKeyConfig = Config.Bind("HUDSections", "InstrumentsToggleKey", KeyCode.None, "Optional collapse key.");
            _cargoToggleKeyConfig = Config.Bind("HUDSections", "CargoToggleKey", KeyCode.None, "Optional collapse key.");
            _soundingToggleKeyConfig = Config.Bind("HUDSections", "SoundingToggleKey", KeyCode.None, "Optional collapse key.");
            _statusToggleKeyConfig = Config.Bind("HUDSections", "StatusToggleKey", KeyCode.None, "Optional collapse key.");
            _weatherToggleKeyConfig = Config.Bind("HUDSections", "WeatherToggleKey", KeyCode.None, "Optional collapse key.");

            _fontNameConfig = Config.Bind("Appearance", "FontName", "auto",
                "Font for the HUD. 'auto' picks the first non-Arial font loaded by the game (usually Sailwind's " +
                "own sign/UI font). 'default' forces the plain IMGUI font. Or give part of a font name - enable " +
                "DebugMassReadout once to log the available font names to the BepInEx console.");
            _fontSizeConfig = Config.Bind("Appearance", "FontSize", 13, "HUD text size.");
            _panelAlphaConfig = Config.Bind("Appearance", "PanelAlpha", 0.18f,
                "Opacity of the section background panels (0 = invisible, 1 = solid).");
            _textAlphaConfig = Config.Bind("Appearance", "TextAlpha", 0.95f,
                "Opacity of the HUD text.");
            _textShadowConfig = Config.Bind("Appearance", "TextShadow", true,
                "Draw a subtle dark drop-shadow behind the text. Makes the HUD readable against a bright " +
                "daytime sky without making the panels darker.");

            _requireChipLogConfig = Config.Bind("EquipmentRequirements", "RequireChipLogForSpeed", true,
                "Only show Speed when a chip log is aboard.");
            _requireCompassConfig = Config.Bind("EquipmentRequirements", "RequireCompassForHeading", true,
                "Only show Heading when a compass is aboard.");
            _requireWindIndicatorConfig = Config.Bind("EquipmentRequirements", "RequireWindIndicatorForWind", true,
                "Only show Wind when a wind indicator (shipyard windicator, tell tale, wind compass) is on the ship.");
            _chipLogNamesConfig = Config.Bind("EquipmentRequirements", "ChipLogItemNames", "chip log,chiplog",
                "Comma-separated name fragments identifying a chip log item aboard.");
            _compassNamesConfig = Config.Bind("EquipmentRequirements", "CompassItemNames", "compass",
                "Comma-separated name fragments identifying a compass item aboard.");
            _windIndicatorNamesConfig = Config.Bind("EquipmentRequirements", "WindIndicatorNames",
                "windicator,tell tale,telltale,wind indicator,wind compass,windsock",
                "Comma-separated name fragments identifying a wind indicator anywhere on the boat or its model.");

            RebuildShipProfiles();
            _shipProfilesConfig.SettingChanged += delegate { RebuildShipProfiles(); };
        }

        private void RebuildShipProfiles()
        {
            _shipProfiles.Clear();
            string raw = _shipProfilesConfig.Value ?? "";
            foreach (string entry in raw.Split(new char[] { ';' }))
            {
                string trimmed = entry.Trim();
                if (trimmed.Length == 0) continue;
                int eq = trimmed.IndexOf('=');
                if (eq <= 0 || eq == trimmed.Length - 1) continue;
                string namePart = trimmed.Substring(0, eq).Trim();
                string weightPart = trimmed.Substring(eq + 1).Trim();
                if (namePart.Length == 0) continue;

                string maxPart = weightPart;
                string emptyPart = null;
                int colon = weightPart.IndexOf(':');
                if (colon > 0 && colon < weightPart.Length - 1)
                {
                    maxPart = weightPart.Substring(0, colon).Trim();
                    emptyPart = weightPart.Substring(colon + 1).Trim();
                }

                float maxWeight;
                if (!float.TryParse(maxPart, out maxWeight)) continue;
                ShipProfile profile = new ShipProfile();
                profile.NameContains = namePart;
                profile.MaxWeightLbs = maxWeight;
                float emptyWeight;
                if (emptyPart != null && float.TryParse(emptyPart, out emptyWeight))
                {
                    profile.EmptyWeightLbs = emptyWeight;
                    profile.HasEmptyWeight = true;
                }
                _shipProfiles.Add(profile);
            }
        }

        private ShipProfile GetProfile(string boatName)
        {
            if (!string.IsNullOrEmpty(boatName))
            {
                foreach (ShipProfile profile in _shipProfiles)
                {
                    if (boatName.IndexOf(profile.NameContains, StringComparison.OrdinalIgnoreCase) >= 0)
                        return profile;
                }
            }
            return null;
        }

        private void GetBurden(float loadLbs, float maxSafeWeightLbs, out string label, out Color color)
        {
            float pct = maxSafeWeightLbs > 0f ? (loadLbs / maxSafeWeightLbs) * 100f : 0f;
            if (pct >= _overloadedThresholdPctConfig.Value) { label = "Overloaded"; color = Color.red; return; }
            if (pct >= _loadedThresholdPctConfig.Value) { label = "Loaded"; color = Color.yellow; return; }
            if (pct >= _lightThresholdPctConfig.Value) { label = "Normal"; color = Color.white; return; }
            label = "Light"; color = Color.white;
        }

        private static bool KeyPressed(ConfigEntry<KeyCode> entry)
        {
            return entry != null && entry.Value != KeyCode.None && Input.GetKeyDown(entry.Value);
        }

        private static bool NameMatchesAny(string name, string commaList)
        {
            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(commaList)) return false;
            foreach (string fragment in commaList.Split(new char[] { ',' }))
            {
                string f = fragment.Trim();
                if (f.Length == 0) continue;
                if (name.IndexOf(f, StringComparison.OrdinalIgnoreCase) >= 0) return true;
            }
            return false;
        }

        private static string CompassPoint(float degrees)
        {
            degrees = degrees % 360f;
            if (degrees < 0f) degrees += 360f;
            int index = (int)Mathf.Round(degrees / 22.5f) % 16;
            return CompassPoints[index];
        }

        private static string WindWord(float knots)
        {
            if (knots < 1f) return "Calm";
            if (knots < 7f) return "Light Air";
            if (knots < 17f) return "Breeze";
            if (knots < 27f) return "Fresh Breeze";
            if (knots < 38f) return "Strong Wind";
            return "Gale";
        }

        private void Update()
        {
            if (KeyPressed(_hudToggleKeyConfig)) _hudVisibleConfig.Value = !_hudVisibleConfig.Value;
            if (KeyPressed(_instrumentsToggleKeyConfig)) _showInstrumentsConfig.Value = !_showInstrumentsConfig.Value;
            if (KeyPressed(_cargoToggleKeyConfig)) _showCargoConfig.Value = !_showCargoConfig.Value;
            if (KeyPressed(_soundingToggleKeyConfig)) _showSoundingConfig.Value = !_showSoundingConfig.Value;
            if (KeyPressed(_statusToggleKeyConfig)) _showStatusConfig.Value = !_showStatusConfig.Value;
            if (KeyPressed(_weatherToggleKeyConfig)) _showWeatherConfig.Value = !_showWeatherConfig.Value;

            _snapValid = false;
            if (!GameState.playing || GameState.justStarted || GameState.lastBoat == null) return;

            Transform boat = GameState.lastBoat;
            BoatDamage boatDamage = boat.GetComponent<BoatDamage>();
            Rigidbody boatRigidbody = boat.GetComponent<Rigidbody>();
            if (boatDamage == null || boatRigidbody == null) return;

            // --- Instruments ---
            Vector3 rawVelocity = boatRigidbody.velocity;
            float forwardSpeed = Vector3.Dot(rawVelocity, boat.forward);
            _snapSpeedKts = forwardSpeed * 1.94384f;
            if (Mathf.Abs(_snapSpeedKts) < 0.1f) _snapSpeedKts = 0f;

            Vector3 fwd = boat.forward;
            fwd.y = 0f;
            if (fwd.sqrMagnitude > 0.0001f)
            {
                float heading = Mathf.Atan2(fwd.x, fwd.z) * Mathf.Rad2Deg;
                if (heading < 0f) heading += 360f;
                _snapHeadingDeg = heading;
            }

            _snapHeel = Vector3.Angle(boat.up, Vector3.up);
            // If the starboard rail is lifted, the ship is heeling to port.
            _snapHeelPort = boat.right.y > 0f;
            _snapHeelLimit = boatDamage.safeAngleLimit;

            // --- Weather ---
            _snapWindKts = Wind.currentWind.magnitude * 1.94384f;
            Vector3 windFrom = -Wind.currentWind;
            windFrom.y = 0f;
            if (windFrom.sqrMagnitude > 0.0001f)
            {
                float fromDeg = Mathf.Atan2(windFrom.x, windFrom.z) * Mathf.Rad2Deg;
                if (fromDeg < 0f) fromDeg += 360f;
                _snapWindFromDeg = fromDeg;
            }
            UpdateConditions();

            // --- Status ---
            _snapHullDamagePct = boatDamage.hullDamage * 100f;
            _snapBilgePct = boatDamage.waterLevel * 100f;
            _snapSunk = boatDamage.sunk;
            _snapBoatName = boat.name;

            // Bilge water carries NO mass in Sailwind (verified from BoatDamage.UpdateWaterAndDrag):
            // below 50% it only adds drag; above 50% it scales buoyancy down to 66% at full.
            // A buoyancy cut to fraction k settles the hull exactly like carrying mass*(1/k - 1)
            // of extra weight, so that equivalent counts toward Deadweight and Burden.
            float buoyancyFraction = Mathf.Lerp(1f, 0.66f, (boatDamage.waterLevel - 0.5f) * 2f);
            _snapBilgeEqLbs = 0f;
            if (buoyancyFraction < 0.999f)
            {
                _snapBilgeEqLbs = boatRigidbody.mass * (1f / buoyancyFraction - 1f);
            }

            // --- Cargo / Deadweight ---
            // Deadweight = everything the ship carries to operate: all items aboard (loose AND stowed
            // in containers), the crew (the game models the player as exactly 160), and the effective
            // weight of any bilge water. It deliberately excludes the hull and shipyard fittings.
            BoatMass boatMass = boat.GetComponent<BoatMass>();
            float itemsWeight = 0f;
            float selfMass = 0f;
            float partsMass = 0f;
            bool hasChipLogNow = false;
            bool hasCompassNow = false;
            if (boatMass != null)
            {
                selfMass = (float)SelfMassField.GetValue(boatMass);
                partsMass = (float)PartsMassField.GetValue(boatMass);
                object itemsRaw = ItemsOnBoatField.GetValue(boatMass);
                System.Collections.IEnumerable items = itemsRaw as System.Collections.IEnumerable;
                if (items != null)
                {
                    foreach (object itemObj in items)
                    {
                        ItemRigidbody item = itemObj as ItemRigidbody;
                        if (item == null) continue;
                        Rigidbody itemBody = item.GetBody();
                        if (itemBody == null) continue;
                        itemsWeight += itemBody.mass;
                        string itemName = item.name;
                        if (!hasChipLogNow && NameMatchesAny(itemName, _chipLogNamesConfig.Value)) hasChipLogNow = true;
                        if (!hasCompassNow && NameMatchesAny(itemName, _compassNamesConfig.Value)) hasCompassNow = true;
                    }
                }
            }
            bool playerAboard = GameState.currentBoat != null && GameState.currentBoat.parent == boat;
            _snapDeadweightLbs = itemsWeight + _snapBilgeEqLbs + (playerAboard ? PlayerMassLbs : 0f);
            _snapSelfMass = selfMass;
            _snapPartsMass = partsMass;
            _hasChipLog = hasChipLogNow;
            _hasCompass = hasCompassNow;

            // --- Burden ---
            ShipProfile profile = GetProfile(_snapBoatName);
            _snapProfileMatched = profile != null;
            _snapMaxSafeLbs = profile != null ? profile.MaxWeightLbs : _defaultMaxWeightLbsConfig.Value;
            if (profile != null && profile.HasEmptyWeight)
            {
                float totalNow = selfMass + partsMass + itemsWeight + _snapBilgeEqLbs + (playerAboard ? PlayerMassLbs : 0f);
                float load = totalNow - profile.EmptyWeightLbs;
                if (load < 0f) load = 0f;
                _snapBurdenLoadLbs = load;
                _snapBurdenIsTotalBased = true;
            }
            else
            {
                _snapBurdenLoadLbs = _snapDeadweightLbs;
                _snapBurdenIsTotalBased = false;
            }

            // --- Wind indicator scan (1 Hz - walks child transforms) ---
            _equipScanTimer -= Time.deltaTime;
            if (_equipScanTimer <= 0f)
            {
                _equipScanTimer = 1f;
                _hasWindIndicator = ScanForWindIndicator(boat);
            }

            // --- Sounding + Freeboard (throttled - raycast + collider walk) ---
            _keelTimer -= Time.deltaTime;
            if (_keelTimer <= 0f)
            {
                _keelTimer = 0.2f;
                UpdateSounding(boat, boatRigidbody);
            }

            _snapValid = true;
        }

        private void UpdateConditions()
        {
            // Conditions read ONLY the game's wandering-storm system - never raw wind speed, so a
            // gusty-but-clear day never shows as bad weather. WeatherStorms.currentStormDistance is
            // normalized 1 = clear of any storm .. 0 = inside a storm; the game turns the sky cloudy
            // below cloudyBorder (default 0.4) and rainy below rainBorder (default 0.1). We read the
            // live borders when available and fall back to those defaults.
            float cloudyBorder = 0.4f;
            float rainBorder = 0.1f;
            float proximityRaw = 1f; // assume clear if the storm system isn't present
            WeatherStorms storms = WeatherStorms.instance;
            if (storms != null)
            {
                try
                {
                    if (CloudyBorderField != null) cloudyBorder = (float)CloudyBorderField.GetValue(storms);
                    if (RainBorderField != null) rainBorder = (float)RainBorderField.GetValue(storms);
                }
                catch (Exception) { }
                proximityRaw = WeatherStorms.currentStormDistance;
            }

            // Smooth the proximity so a value dithering on a boundary doesn't jitter the reading.
            if (!_stormProximityInit)
            {
                _stormProximity = proximityRaw;
                _stormProximityInit = true;
            }
            else
            {
                _stormProximity = Mathf.Lerp(_stormProximity, proximityRaw, Time.deltaTime * 0.6f);
            }

            // Two boundaries derived from the game's own thresholds:
            //   >= cloudyBorder            -> Fair      (severity 0)
            //   midpoint..cloudyBorder     -> Moderate  (severity 1)
            //   rainBorder..midpoint       -> Squally   (severity 2)
            //   <  rainBorder              -> Tempest   (severity 3)
            float squallyBorder = (cloudyBorder + rainBorder) * 0.5f;

            // Hysteresis: only cross a boundary once the smoothed value is a margin PAST it, and only
            // after the new state has persisted briefly. This kills the Moderate<->Squally flicker.
            const float margin = 0.04f;
            int target;
            float p = _stormProximity;
            if (p >= cloudyBorder + margin) target = 0;
            else if (p >= squallyBorder + margin) target = 1;
            else if (p >= rainBorder + margin) target = 2;
            else target = 3;

            // If moving toward CLEARER weather, require the value to be clearly back inside the calmer
            // band (the +margin above already does this). If the smoothed value sits within +/- margin
            // of a boundary, hold the current severity rather than flipping.
            if (Mathf.Abs(p - cloudyBorder) < margin ||
                Mathf.Abs(p - squallyBorder) < margin ||
                Mathf.Abs(p - rainBorder) < margin)
            {
                target = _snapConditionSeverity;
            }

            // Require a new state to persist ~2s of accumulated time before committing to it, so brief
            // excursions never register as a weather change.
            if (target != _snapConditionSeverity)
            {
                _conditionHoldTimer += Time.deltaTime;
                if (_conditionHoldTimer >= 2f)
                {
                    _snapConditionSeverity = target;
                    _conditionHoldTimer = 0f;
                }
            }
            else
            {
                _conditionHoldTimer = 0f;
            }
        }

        private bool ScanForWindIndicator(Transform boat)
        {
            string names = _windIndicatorNamesConfig.Value;
            if (ScanChildrenForName(boat, names)) return true;
            BoatRefs refs = boat.GetComponent<BoatRefs>();
            if (refs != null && refs.boatModel != null && ScanChildrenForName(refs.boatModel, names)) return true;
            return false;
        }

        private static bool ScanChildrenForName(Transform root, string commaList)
        {
            Transform[] children = root.GetComponentsInChildren<Transform>(false);
            for (int i = 0; i < children.Length; i++)
            {
                if (NameMatchesAny(children[i].name, commaList)) return true;
            }
            return false;
        }

        // Collider names that belong to rigging (masts/stays/shrouds/sails), which on some modded
        // ships carry their own tall MeshColliders and must never be mistaken for the deck.
        private static readonly string[] RiggingTokens = new string[] {
            "mast", "stay", "shroud", "sail", "yard", "boom", "gaff", "sprit", "rigg",
            "halyard", "sheet", "vang", "spar", "topmast" };
        // Collider names that positively identify the hull/deck structure.
        private static readonly string[] HullDeckTokens = new string[] {
            "hull", "deck", "gunwale", "gunnel", "bulwark", "reinforced", "walk" };

        private static bool ContainsToken(string name, string[] tokens)
        {
            if (string.IsNullOrEmpty(name)) return false;
            for (int i = 0; i < tokens.Length; i++)
            {
                if (name.IndexOf(tokens[i], StringComparison.OrdinalIgnoreCase) >= 0) return true;
            }
            return false;
        }

        private static bool IsRiggingName(string name) { return ContainsToken(name, RiggingTokens); }
        private static bool IsHullDeckName(string name) { return ContainsToken(name, HullDeckTokens); }

        private void UpdateSounding(Transform boat, Rigidbody boatRigidbody)
        {
            _snapKeelClearance = 999f;
            _snapSeaDepth = 999f;
            _snapKeelHitName = "(no hit)";

            // Keel and deck are measured in the BOAT'S OWN LOCAL SPACE, not world space. Unity's
            // collider.bounds is a WORLD axis-aligned box: when the ship heels, a long horizontal
            // deck collider's world AABB grows taller, so its world .max.y rides up and down with the
            // roll - which is why an earlier version's freeboard tracked the heel angle. By expressing
            // each collider's extents along the boat's own up-axis, heeling no longer affects them.
            //
            // For each collider we take its 8 world corners, project onto the boat's up direction
            // relative to the boat origin, and keep the min/max. That gives a heel-invariant local
            // height for keel (min) and deck (max).
            Vector3 boatUp = boat.up;
            Vector3 boatPos = boat.position;
            float hullBottomLocal = float.PositiveInfinity;
            float namedDeckTopLocal = float.NegativeInfinity;
            float fallbackTopLocal = float.NegativeInfinity;
            float fallbackVolume = -1f;
            Collider[] boatColliders = boat.GetComponentsInChildren<Collider>();
            foreach (Collider col in boatColliders)
            {
                if (col == null || col.isTrigger || !col.enabled) continue;
                Bounds b = col.bounds;

                // Project the collider's 8 world-space corners onto the boat up-axis.
                Vector3 c = b.center;
                Vector3 e = b.extents;
                float colMinLocal = float.PositiveInfinity;
                float colMaxLocal = float.NegativeInfinity;
                for (int sx = -1; sx <= 1; sx += 2)
                    for (int sy = -1; sy <= 1; sy += 2)
                        for (int sz = -1; sz <= 1; sz += 2)
                        {
                            Vector3 corner = new Vector3(c.x + sx * e.x, c.y + sy * e.y, c.z + sz * e.z);
                            float localH = Vector3.Dot(corner - boatPos, boatUp);
                            if (localH < colMinLocal) colMinLocal = localH;
                            if (localH > colMaxLocal) colMaxLocal = localH;
                        }

                if (colMinLocal < hullBottomLocal) hullBottomLocal = colMinLocal;

                string cn = col.name;
                if (IsRiggingName(cn)) continue; // masts/stays/shrouds never define the deck

                if (IsHullDeckName(cn))
                {
                    if (colMaxLocal > namedDeckTopLocal) namedDeckTopLocal = colMaxLocal;
                }

                float volume = b.size.x * b.size.y * b.size.z;
                if (volume > fallbackVolume)
                {
                    fallbackVolume = volume;
                    fallbackTopLocal = colMaxLocal;
                }
            }
            if (float.IsPositiveInfinity(hullBottomLocal)) hullBottomLocal = 0f;

            // Prefer hull/deck-named geometry; fall back to the largest non-rigging collider.
            float deckTopLocal = !float.IsNegativeInfinity(namedDeckTopLocal) ? namedDeckTopLocal : fallbackTopLocal;

            // Convert the heel-invariant local heights back to world Y at the boat's current position.
            // (Using boat up keeps keel-clearance geometry consistent with the sounding below.)
            float hullBottomY = boatPos.y + hullBottomLocal * boatUp.y;
            float hullTopY = float.IsNegativeInfinity(deckTopLocal)
                ? float.NegativeInfinity
                : boatPos.y + deckTopLocal * boatUp.y;

            // Live water surface height. Ocean.GetWaterHeightAtLocation2 returns the wave heightfield
            // sample, which the game's own float scripts (Boyant.Update) use directly as world Y.
            // In a big swell a single sample under the boat origin can sit on a crest while the bow
            // is in a trough (or vice-versa), which made freeboard swing wildly at sea. So we sample
            // the water at several points spread along the hull (bow, stern, port, starboard, center)
            // and average them - that cancels the wave tilt and gives the MEAN waterline under the
            // ship, which is what freeboard should really be measured against.
            float waterY = 0f;
            Ocean oceanInstance = Ocean.Singleton;
            if (oceanInstance != null)
            {
                Vector3 f = boat.forward; f.y = 0f; f = f.sqrMagnitude > 0.0001f ? f.normalized : Vector3.forward;
                Vector3 r = boat.right; r.y = 0f; r = r.sqrMagnitude > 0.0001f ? r.normalized : Vector3.right;
                // Spread roughly to the hull's own half-extents so the samples straddle real waves.
                float halfLen = Mathf.Max(2f, (deckTopLocal - hullBottomLocal) * 1.5f);
                float halfBeam = Mathf.Max(1.5f, halfLen * 0.4f);
                Vector3 p = boat.position;
                float sum = 0f; int n = 0;
                Vector3[] offsets = new Vector3[] {
                    Vector3.zero,
                    f * halfLen, f * -halfLen,
                    r * halfBeam, r * -halfBeam
                };
                for (int i = 0; i < offsets.Length; i++)
                {
                    Vector3 s = p + offsets[i];
                    sum += oceanInstance.GetWaterHeightAtLocation2(s.x, s.z);
                    n++;
                }
                waterY = sum / n;
            }

            // Freeboard: deck edge above the MEAN waterline, heavily smoothed. Freeboard is a
            // slow-changing property of how the ship sits (load + sea state), not something that
            // should track each passing wave, so we smooth on a ~2s time constant. The hull's own
            // keel-to-deck height is a hard physical ceiling against any stray tall collider.
            if (!float.IsNegativeInfinity(hullTopY))
            {
                float hullHeight = deckTopLocal - hullBottomLocal;
                float freeboardNow = hullTopY - waterY;
                if (freeboardNow < 0f) freeboardNow = 0f;
                if (hullHeight > 0f && freeboardNow > hullHeight) freeboardNow = hullHeight;
                if (!_freeboardInitialized)
                {
                    _snapFreeboard = freeboardNow;
                    _freeboardInitialized = true;
                }
                else
                {
                    // Time-constant smoothing (~2s) independent of the 0.2s sounding cadence.
                    float k = 1f - Mathf.Exp(-0.2f / 2f);
                    _snapFreeboard = Mathf.Lerp(_snapFreeboard, freeboardNow, k);
                }
            }

            // Sounding line: see v1.2 notes. Sailwind keeps a separate walkable copy of the hull
            // (the "WALK <ship>" object, layer 8, tag 'WalkColBoat') that is NOT a hierarchy child
            // of the physics boat, plus large trigger volumes riding along with it - both of which
            // the naive raycast kept re-hitting at constant distance on modded ships.
            Transform walkCol = null;
            Transform boatModel = null;
            BoatRefs refs = boat.GetComponent<BoatRefs>();
            if (refs != null)
            {
                walkCol = refs.walkCol;
                boatModel = refs.boatModel;
            }

            Vector3 origin = new Vector3(boat.position.x, boat.position.y + 5f, boat.position.z);
            int mask = Physics.DefaultRaycastLayers & ~(1 << 8) & ~(1 << 4);
            int customWaterLayer = LayerMask.NameToLayer("water");
            if (customWaterLayer >= 0) mask &= ~(1 << customWaterLayer);
            RaycastHit[] hits = Physics.RaycastAll(origin, Vector3.down, 300f, mask, QueryTriggerInteraction.Ignore);

            bool found = false;
            float bestY = float.NegativeInfinity;
            string bestName = "";
            for (int i = 0; i < hits.Length; i++)
            {
                Collider c = hits[i].collider;
                if (c == null) continue;
                if (c.attachedRigidbody != null) continue;
                Transform t = c.transform;
                if (t.IsChildOf(boat)) continue;
                if (walkCol != null && t.IsChildOf(walkCol)) continue;
                if (boatModel != null && t.IsChildOf(boatModel)) continue;
                if (c.gameObject.tag == "WalkColBoat") continue;
                string rootName = t.root != null ? t.root.name : "";
                if (rootName.StartsWith("BOAT", StringComparison.OrdinalIgnoreCase)) continue;
                if (rootName.StartsWith("WALK", StringComparison.OrdinalIgnoreCase)) continue;
                if (hits[i].point.y > hullBottomY + 0.05f) continue;

                if (!found || hits[i].point.y > bestY)
                {
                    found = true;
                    bestY = hits[i].point.y;
                    bestName = c.name;
                }
            }

            if (found)
            {
                _snapKeelClearance = hullBottomY - bestY;
                if (_snapKeelClearance < 0f) _snapKeelClearance = 0f;
                _snapSeaDepth = boat.position.y - bestY;
                _snapKeelHitName = bestName;
            }
        }

        // ---------------- HUD ----------------

        private struct HudLine
        {
            public string Text;
            public Color Color;
        }

        private class HudSection
        {
            public string Name;
            public ConfigEntry<bool> Toggle;
            public List<HudLine> Lines = new List<HudLine>();
        }

        private Texture2D _panelTexture;
        private float _panelTextureAlpha = -1f;

        private Texture2D GetPanelTexture()
        {
            float alpha = Mathf.Clamp01(_panelAlphaConfig.Value);
            if (_panelTexture == null || Mathf.Abs(alpha - _panelTextureAlpha) > 0.01f)
            {
                if (_panelTexture == null)
                {
                    _panelTexture = new Texture2D(1, 1, TextureFormat.ARGB32, false);
                    _panelTexture.hideFlags = HideFlags.HideAndDontSave;
                }
                // Slightly warm-tinted dark, a nod to aged wood/parchment ink without a bright panel.
                _panelTexture.SetPixel(0, 0, new Color(0.09f, 0.07f, 0.04f, alpha));
                _panelTexture.Apply();
                _panelTextureAlpha = alpha;
            }
            return _panelTexture;
        }

        private Font GetGameFont()
        {
            string want = _fontNameConfig.Value ?? "auto";
            if (want == "default") return null;
            if (_fontSearched) return _gameFont;
            _fontSearched = true;

            UnityEngine.Object[] fonts = Resources.FindObjectsOfTypeAll(typeof(Font));
            if (_debugReadoutConfig.Value)
            {
                string names = "";
                for (int i = 0; i < fonts.Length; i++) names += (i > 0 ? ", " : "") + fonts[i].name;
                Logger.LogInfo("[" + PluginInfo.Name + "] Fonts loaded by the game: " + names);
            }
            for (int i = 0; i < fonts.Length; i++)
            {
                Font f = fonts[i] as Font;
                if (f == null) continue;
                string n = f.name ?? "";
                if (want != "auto")
                {
                    if (n.IndexOf(want, StringComparison.OrdinalIgnoreCase) >= 0) { _gameFont = f; break; }
                }
                else
                {
                    if (n.IndexOf("Arial", StringComparison.OrdinalIgnoreCase) < 0 && n.Length > 0)
                    {
                        _gameFont = f;
                        break;
                    }
                }
            }
            if (_gameFont != null)
            {
                Logger.LogInfo("[" + PluginInfo.Name + "] Using game font: " + _gameFont.name);
            }
            return _gameFont;
        }

        private void OnGUI()
        {
            if (!_snapValid) return;
            if (!_hudVisibleConfig.Value) return;

            float textAlpha = Mathf.Clamp01(_textAlphaConfig.Value);

            GUIStyle textStyle = new GUIStyle();
            textStyle.fontSize = _fontSizeConfig.Value;
            textStyle.fontStyle = FontStyle.Normal;
            Font gameFont = GetGameFont();
            if (gameFont != null) textStyle.font = gameFont;
            // Warm near-white "ink on dark" to pair with the panel tint.
            textStyle.normal.textColor = new Color(0.99f, 0.97f, 0.92f, textAlpha);

            GUIStyle headerStyle = new GUIStyle(textStyle);
            headerStyle.normal.textColor = new Color(0.99f, 0.97f, 0.92f, textAlpha * 0.85f);

            GUIStyle shadowStyle = new GUIStyle(textStyle);
            shadowStyle.normal.textColor = new Color(0f, 0f, 0f, textAlpha * 0.8f);
            bool drawShadow = _textShadowConfig.Value;

            GUIStyle bulletStyle = new GUIStyle(GUI.skin.button);
            bulletStyle.fontSize = 9;
            bulletStyle.padding = new RectOffset(0, 0, 0, 0);
            bulletStyle.margin = new RectOffset(0, 0, 0, 0);
            bulletStyle.alignment = TextAnchor.MiddleCenter;

            Color heelColor = (_snapHeel > _snapHeelLimit) ? Color.yellow : Color.white;
            Color damageColor = (_snapHullDamagePct >= 95f) ? Color.red : (_snapHullDamagePct > 15f) ? Color.yellow : Color.white;
            Color bilgeColor = _snapSunk ? Color.red : (_snapBilgePct > 15f) ? Color.yellow : Color.white;
            Color clearanceColor = (_snapKeelClearance <= 0.1f) ? Color.red : (_snapKeelClearance < 2.0f) ? Color.yellow : Color.white;
            Color freeboardColor = (_snapFreeboard <= 0.15f) ? Color.red : (_snapFreeboard < 0.6f) ? Color.yellow : Color.white;

            string burdenLabel;
            Color burdenColor;
            GetBurden(_snapBurdenLoadLbs, _snapMaxSafeLbs, out burdenLabel, out burdenColor);

            List<HudSection> sections = new List<HudSection>();
            HudSection current = null;

            void Section(string name, ConfigEntry<bool> toggle)
            {
                current = new HudSection();
                current.Name = name;
                current.Toggle = toggle;
                sections.Add(current);
            }
            void Line(string text, Color color)
            {
                HudLine l = new HudLine();
                l.Text = text;
                l.Color = color;
                current.Lines.Add(l);
            }

            Color plain = Color.white;

            // Group 1: Instruments
            Section("Instruments", _showInstrumentsConfig);
            if (_showInstrumentsConfig.Value)
            {
                if (_hasChipLog || !_requireChipLogConfig.Value)
                    Line("Speed    : " + _snapSpeedKts.ToString("F1") + " kts", plain);
                if (_hasCompass || !_requireCompassConfig.Value)
                    Line("Heading  : " + _snapHeadingDeg.ToString("000") + "\u00B0 " + CompassPoint(_snapHeadingDeg), plain);
                string heelText = _snapHeel < 0.05f
                    ? "Heel     : 0.0\u00B0"
                    : "Heel     : " + _snapHeel.ToString("F1") + "\u00B0 " + (_snapHeelPort ? "Port" : "Stbd");
                Line(heelText, heelColor);
            }

            // Group 2: Cargo
            Section("Cargo", _showCargoConfig);
            if (_showCargoConfig.Value)
            {
                Line("Deadweight : " + _snapDeadweightLbs.ToString("F0") + " lbs", burdenColor);
                Line("Freeboard  : " + _snapFreeboard.ToString("F1") + " m", freeboardColor);
                string burdenText = "Burden     : " + burdenLabel;
                if (!_snapProfileMatched) burdenText += " (no profile)";
                else if (_snapBurdenIsTotalBased) burdenText += " (total wt)";
                Line(burdenText, _snapProfileMatched ? burdenColor : Color.gray);
                if (_debugReadoutConfig.Value)
                {
                    Line("Hull: " + _snapSelfMass.ToString("F0") + "  Parts: " + _snapPartsMass.ToString("F0"), plain);
                    Line("Total Weight: " + (_snapSelfMass + _snapPartsMass + _snapDeadweightLbs - _snapBilgeEqLbs).ToString("F0"), plain);
                    Line("Bilge Eq: " + _snapBilgeEqLbs.ToString("F0") + " lbs", plain);
                    Line("Boat: " + _snapBoatName, plain);
                    Line("Capacity: " + _snapMaxSafeLbs.ToString("F0") + " lbs", plain);
                }
            }

            // Group 3: Sounding
            Section("Sounding", _showSoundingConfig);
            if (_showSoundingConfig.Value)
            {
                Line("Sea Depth      : " + (_snapSeaDepth > 290f ? "Deep Ocean" : _snapSeaDepth.ToString("F1") + " m"), plain);
                string clearanceText = _snapKeelClearance > 290f ? "Safe" : _snapKeelClearance.ToString("F1") + " m";
                Line("Keel Clearance : " + clearanceText, clearanceColor);
                if (_debugReadoutConfig.Value)
                {
                    Line("Sounding Hit: " + _snapKeelHitName, plain);
                }
            }

            // Group 4: Status
            Section("Status", _showStatusConfig);
            if (_showStatusConfig.Value)
            {
                Line("Hull Integrity : " + (100f - _snapHullDamagePct).ToString("F1") + "%", damageColor);
                Line("Bilge Water    : " + _snapBilgePct.ToString("F1") + "%", bilgeColor);
            }

            // Group 5: Weather
            Section("Weather", _showWeatherConfig);
            if (_showWeatherConfig.Value)
            {
                if (_hasWindIndicator || !_requireWindIndicatorConfig.Value)
                    Line("Wind       : " + CompassPoint(_snapWindFromDeg) + " " + WindWord(_snapWindKts), plain);
                string conditionWord;
                Color conditionColor;
                switch (_snapConditionSeverity)
                {
                    case 3: conditionWord = "Tempest"; conditionColor = Color.red; break;
                    case 2: conditionWord = "Squally"; conditionColor = Color.yellow; break;
                    case 1: conditionWord = "Moderate"; conditionColor = Color.white; break;
                    default: conditionWord = "Fair"; conditionColor = new Color(0.6f, 1f, 0.6f); break;
                }
                Line("Conditions : " + conditionWord, conditionColor);
            }

            // ---- Draw ----
            float x = 20f;
            float y = 60f;
            float lineHeight = _fontSizeConfig.Value + 3f;
            float padX = 5f;
            float padY = 3f;
            float gap = 3f;
            float bulletSize = 11f;
            float textIndent = bulletSize + 5f;
            Texture2D panelTex = GetPanelTexture();

            foreach (HudSection section in sections)
            {
                bool expanded = section.Toggle.Value;

                // Panel width hugs the longest line (or the section name when collapsed).
                float contentWidth;
                if (expanded)
                {
                    contentWidth = 0f;
                    foreach (HudLine line in section.Lines)
                    {
                        Vector2 size = textStyle.CalcSize(new GUIContent(line.Text));
                        if (size.x > contentWidth) contentWidth = size.x;
                    }
                    if (section.Lines.Count == 0) contentWidth = headerStyle.CalcSize(new GUIContent(section.Name)).x;
                }
                else
                {
                    contentWidth = headerStyle.CalcSize(new GUIContent(section.Name)).x;
                }
                float panelWidth = padX + textIndent + contentWidth + padX;
                float height = expanded
                    ? Mathf.Max(1, section.Lines.Count) * lineHeight + padY * 2f
                    : lineHeight + padY * 2f;

                GUI.DrawTexture(new Rect(x, y, panelWidth, height), panelTex);

                // Bullet-style collapse button on the LEFT, out of the field of view.
                Color prevColor = GUI.color;
                GUI.color = new Color(1f, 1f, 1f, 0.35f);
                if (GUI.Button(new Rect(x + padX, y + padY + (lineHeight - bulletSize) * 0.5f, bulletSize, bulletSize),
                        expanded ? "-" : "+", bulletStyle))
                {
                    section.Toggle.Value = !expanded;
                }
                GUI.color = prevColor;

                if (expanded)
                {
                    for (int i = 0; i < section.Lines.Count; i++)
                    {
                        HudLine line = section.Lines[i];
                        GUIStyle style = textStyle;
                        if (line.Color != Color.white)
                        {
                            style = new GUIStyle(textStyle);
                            Color c = line.Color;
                            c.a = textAlpha;
                            style.normal.textColor = c;
                        }
                        Rect lineRect = new Rect(x + padX + textIndent, y + padY + i * lineHeight, contentWidth + 4f, lineHeight + 4f);
                        if (drawShadow)
                        {
                            GUI.Label(new Rect(lineRect.x + 1f, lineRect.y + 1f, lineRect.width, lineRect.height),
                                line.Text, shadowStyle);
                        }
                        GUI.Label(lineRect, line.Text, style);
                    }
                }
                else
                {
                    // Category name shows ONLY while minimized.
                    Rect headerRect = new Rect(x + padX + textIndent, y + padY, contentWidth + 4f, lineHeight + 4f);
                    if (drawShadow)
                    {
                        GUI.Label(new Rect(headerRect.x + 1f, headerRect.y + 1f, headerRect.width, headerRect.height),
                            section.Name, shadowStyle);
                    }
                    GUI.Label(headerRect, section.Name, headerStyle);
                }

                y += height + gap;
            }
        }

        // ------------------------------------------------------------------------------------------
        // Weight notes (verified from the game's IL): BoatMass.UpdateMass computes Rigidbody.mass as
        // selfMass + partsMass + loose item masses + installed part masses AGAIN (base-game double
        // count) + a live sail-deployment term + 160 for the player. Rigidbody.mass is therefore
        // never usable as "tare + cargo". Deadweight here sums the items in BoatMass.itemsOnBoat
        // directly (loose and stowed), plus the game's own 160 player mass when aboard, plus the
        // buoyancy-equivalent weight of bilge water. Item mass IS the number the game's market UI
        // calls "Weight" (confirmed in-game: iron crate = 380); no unit conversion is applied.
        // ------------------------------------------------------------------------------------------
    }
}
